<?php
echo '<pre>';
print_r($participants);
echo '</pre>';
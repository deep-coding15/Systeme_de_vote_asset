import hashlib
import random

# Hash SHA-256 du mot de passe "12345678"
password = "12345678"
password_hash = hashlib.sha256(password.encode()).hexdigest()

# Listes de noms et prénoms marocains
noms = [
    "Alaoui", "Bennani", "El Amrani", "Idrissi", "Tazi", "Hassani", "Chraibi", "Fassi",
    "Filali", "Berrada", "Lahlou", "Sabri", "Kadiri", "Zaki", "Mrani", "Ouazzani",
    "Bennis", "Kettani", "Benjelloun", "Cherkaoui", "Sekkat", "Tounsi", "Hajji", "Alami",
    "Bekkali", "Lemrani", "Skalli", "Raji", "Sefiani", "Nejjar", "Benslimane", "Zahraoui",
    "Moutaouakil", "Ghazali", "Lazrak", "Mansouri", "Drissi", "Bouziane", "Tahiri", "Kabbaj",
    "Belghazi", "Naciri", "Elharrak", "Zaari", "Slaoui", "Hilali", "Bouhsine", "Lamrani",
    "Jilali", "Moussaoui", "Chakir", "Benabdallah", "Sqalli", "Ouahabi", "Semlali", "Bensaid",
    "Jaidi", "Slimani", "Bouchentouf", "Amrani", "Lazaar", "Ouardi", "Bouabid", "Chafi"
]

prenoms_hommes = [
    "Mohammed", "Youssef", "Rachid", "Omar", "Karim", "Hassan", "Mehdi", "Amine",
    "Aziz", "Saad", "Bilal", "Hicham", "Adil", "Jalal", "Nabil", "Hamza",
    "Ilyas", "Tarik", "Walid", "Mourad", "Reda", "Fouad", "Khalid", "Said",
    "Abdelilah", "Yassine", "Mustapha", "Hamid", "Abderrahim", "Driss", "Jamal", "Abdellah",
    "Ismail", "Ayoub", "Soufiane", "Anass", "Zakaria", "Othman", "Oussama", "Badr"
]

prenoms_femmes = [
    "Fatima", "Amina", "Khadija", "Zineb", "Laila", "Nadia", "Sara", "Salma",
    "Imane", "Hanane", "Samira", "Meriem", "Dounia", "Hafsa", "Soukaina", "Jihane",
    "Loubna", "Ibtissam", "Siham", "Naoual", "Hasna", "Malika", "Rajae", "Wafa",
    "Houda", "Karima", "Leila", "Asmae", "Btissam", "Hanae", "Samia", "Ghita",
    "Rim", "Chaimae", "Salima", "Houria", "Sanae", "Kenza", "Meryem", "Lamiae"
]

types_documents = ["CNI", "carte-etudiant", "passeport"]

# Ouvrir le fichier SQL
with open("insert_400_participants.sql", "w", encoding="utf-8") as f:
    # Écrire l'en-tête
    f.write("-- Script pour insérer 400 participants dans la table participant\n")
    f.write(f"-- Mot de passe : {password}\n")
    f.write(f"-- Hash SHA-256 : {password_hash}\n\n")
    
    f.write("INSERT INTO participant (nom, prenom, email, password_hash, phone, code_qr, type_document, numero_document, photo_document, est_valide, a_vote) VALUES\n")
    
    # Générer 400 participants
    for i in range(1, 401):
        # Alterner entre hommes et femmes
        if i % 2 == 1:
            prenom = random.choice(prenoms_hommes)
        else:
            prenom = random.choice(prenoms_femmes)
        
        nom = random.choice(noms)
        email = f"{prenom.lower()}.{nom.lower()}{i}@email.com"
        phone = f"06{str(12345000 + i).zfill(9)}"
        code_qr = f"QR{str(i).zfill(3)}"
        type_doc = random.choice(types_documents)
        
        # Numéro de document selon le type
        if type_doc == "CNI":
            num_doc = f"A{123455 + i}"
        elif type_doc == "carte-etudiant":
            num_doc = f"E{123455 + i}"
        else:  # passeport
            num_doc = f"P{123455 + i}"
        
        photo_doc = f"photo_{str(i).zfill(3)}.jpg"
        
        # 80% validés, 20% non validés
        est_valide = 1 if i % 5 != 0 else 0
        
        # Virgule ou point-virgule selon la position
        separateur = "," if i < 400 else ";"
        
        # Écrire la ligne SQL
        ligne = f"('{nom}', '{prenom}', '{email}', '{password_hash}', '{phone}', '{code_qr}', '{type_doc}', '{num_doc}', '{photo_doc}', {est_valide}, 0){separateur}\n"
        f.write(ligne)

print("✅ Fichier 'insert_400_participants.sql' généré avec succès!")
print(f"📊 Mot de passe: {password}")
print(f"🔐 Hash SHA-256: {password_hash}")
print("📝 400 participants créés avec des noms marocains réalistes")
print("✓ ~80% validés, ~20% non validés")
print("✓ Types de documents variés (CNI, carte étudiant, passeport)")
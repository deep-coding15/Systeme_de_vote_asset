import re
import csv
import json

# Mot de passe en clair (identique pour tous)
PASSWORD = "12345678"
DEBUT_ID = 7  # Le ParticipantId commencera à 7

def extraire_emails_du_sql(fichier_sql):
    emails = []
    try:
        with open(fichier_sql, 'r', encoding='utf-8') as f:
            contenu = f.read()
            pattern = r"'([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})'"
            emails = re.findall(pattern, contenu)
    except FileNotFoundError:
        print(f"❌ Erreur: Le fichier '{fichier_sql}' n'existe pas!")
        return []
    except Exception as e:
        print(f"❌ Erreur lors de la lecture: {e}")
        return []
    return emails

def generer_fichier_csv(emails, mot_de_passe, start_id, fichier_sortie="credentials.csv"):
    try:
        with open(fichier_sortie, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['email', 'password', 'participantId'])
            
            # Utilisation de enumerate(emails, start_id) pour l'incrémentation automatique
            for i, email in enumerate(emails, start_id):
                writer.writerow([email, mot_de_passe, i])
        
        print(f"✅ Fichier CSV créé: {fichier_sortie}")
        return True
    except Exception as e:
        print(f"❌ Erreur lors de la création du CSV: {e}")
        return False

def generer_fichier_texte(emails, mot_de_passe, start_id, fichier_sortie="credentials.txt"):
    try:
        with open(fichier_sortie, 'w', encoding='utf-8') as f:
            f.write("=" * 60 + "\n")
            f.write("LISTE DES IDENTIFIANTS\n")
            f.write("=" * 60 + "\n\n")
            
            for i, email in enumerate(emails, start_id):
                f.write(f"ID: {i:<5} | Email: {email:<50} | PWD: {mot_de_passe}\n")
        
        print(f"✅ Fichier TXT créé: {fichier_sortie}")
        return True
    except Exception as e:
        print(f"❌ Erreur lors de la création du TXT: {e}")
        return False

def generer_fichier_json(emails, mot_de_passe, start_id, fichier_sortie="credentials.json"):
    try:
        credentials = [
            {"email": email, "password": mot_de_passe, "id": i}
            for i, email in enumerate(emails, start_id)
        ]
        with open(fichier_sortie, 'w', encoding='utf-8') as f:
            json.dump(credentials, f, indent=2, ensure_ascii=False)
        print(f"✅ Fichier JSON créé: {fichier_sortie}")
        return True
    except Exception as e:
        print(f"❌ Erreur lors de la création du JSON: {e}")
        return False

def afficher_apercu(emails, mot_de_passe, start_id, nombre=5):
    print("\n" + "=" * 60)
    print(f"📋 APERÇU DES {nombre} PREMIERS IDENTIFIANTS (Début ID: {start_id})")
    print("=" * 60 + "\n")
    for i, email in enumerate(emails[:nombre], start_id):
        print(f"ID {i}: {email} (Password: {mot_de_passe})")
    print()

# ============================================
# PROGRAMME PRINCIPAL
# ============================================

if __name__ == "__main__":
    fichier_sql = "insert_400_participants.sql"
    emails = extraire_emails_du_sql(fichier_sql)
    
    if not emails:
        print("❌ Aucun email trouvé.")
    else:
        afficher_apercu(emails, PASSWORD, DEBUT_ID)
        
        # Génération des fichiers avec prise en compte du début de l'ID
        generer_fichier_csv(emails, PASSWORD, DEBUT_ID, "credentials.csv")
        generer_fichier_texte(emails, PASSWORD, DEBUT_ID, "credentials.txt")
        generer_fichier_json(emails, PASSWORD, DEBUT_ID, "credentials.json")
        
        print(f"\n📊 Total: {len(emails)} comptes générés du ID {DEBUT_ID} au ID {DEBUT_ID + len(emails) - 1}")

<?php

?>
<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Site de gestion de vote — Accueil</title>
  <style>
    /* Reset minimal */
    *{box-sizing:border-box;margin:0;padding:0}
    body{
      font-family: Inter, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;
      background: linear-gradient(180deg,#f7fbff 0%, #f0f4fb 100%);
      color:#0f1724;
      -webkit-font-smoothing:antialiased;
      -moz-osx-font-smoothing:grayscale;
      line-height:1.45;
    }

    /* Layout */
    .container{max-width:1150px;margin:36px auto;padding:20px;display:grid;grid-template-columns: 320px 1fr;gap:28px}
    @media (max-width:880px){ .container{grid-template-columns:1fr; padding:16px} }

    /* Sidebar */
    .sidebar{
      background:linear-gradient(180deg, rgba(59,130,246,0.05), rgba(6,182,212,0.03));
      border-radius:14px;padding:18px;box-shadow:0 8px 24px rgba(15,23,36,0.06);
      display:flex;flex-direction:column;gap:14px;height:fit-content;
    }
    .brand{display:flex;align-items:center;gap:12px}
    .logo{width:56px;height:56px;border-radius:12px;background:linear-gradient(135deg,#3751ff,#00c2b3);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;font-size:20px}
    .brand h1{font-size:16px}
    .brand p{font-size:13px;color:#6b7280;margin-top:4px}

    .nav{display:flex;flex-direction:column;gap:8px;margin-top:6px}
    .nav a{color:#0f1724;text-decoration:none;padding:10px;border-radius:10px;font-weight:700;font-size:14px}
    .nav a:hover{background:rgba(2,6,23,0.03)}

    .meta{background:#fff;border-radius:10px;padding:12px;border:1px solid #eef2ff}
    .meta .k{font-size:12px;color:#6b7280}
    .meta .v{font-weight:800;font-size:18px;margin-top:6px}

    /* Main */
    .main{display:flex;flex-direction:column;gap:18px}

    .hero{
      background:linear-gradient(180deg,#ffffff 0%, #f8fafc 100%);
      border-radius:14px;padding:28px;box-shadow:0 10px 28px rgba(15,23,36,0.06);
      display:flex;gap:24px;align-items:center;justify-content:space-between;
    }
    .hero-left{max-width:64%}
    .eyebrow{display:inline-block;padding:6px 10px;background:rgba(59,130,246,0.08);color:#1e3a8a;border-radius:999px;font-weight:700;font-size:13px}
    .title{font-size:28px;font-weight:800;margin-top:12px}
    .subtitle{color:#475569;margin-top:8px;font-size:15px}
    .cta{margin-top:18px}
    .btn-primary{background:#0ea5a4;border:0;color:white;padding:12px 18px;border-radius:10px;font-weight:800;cursor:pointer}
    .info-block{display:flex;gap:12px;align-items:center;margin-top:14px}

    .stat{
      background:#fff;padding:12px;border-radius:12px;border:1px solid #eef2ff;text-align:center;
      min-width:120px;
    }
    .stat .label{font-size:13px;color:#6b7280}
    .stat .value{font-weight:800;font-size:18px;margin-top:6px}

    .hero-right{
      min-width:240px;
      display:flex;flex-direction:column;gap:12px;align-items:flex-end;
    }

    /* About & How to vote */
    .card{background:#fff;padding:18px;border-radius:12px;border:1px solid #eef2ff;box-shadow:0 6px 18px rgba(15,23,36,0.04)}
    .card h3{font-size:18px;margin-bottom:10px}
    .about p{color:#374151;font-size:14px}
    .steps{display:flex;flex-direction:column;gap:10px;margin-top:8px}
    .step{display:flex;gap:12px;align-items:flex-start}
    .step .num{background:linear-gradient(135deg,#3751ff,#00c2b3);color:white;width:36px;height:36px;display:flex;align-items:center;justify-content:center;border-radius:8px;font-weight:800}
    .step .text{color:#374151;font-size:14px}

    /* footer small */
    footer{margin-top:8px;color:#6b7280;font-size:13px}

    /* utilities */
    small.muted{color:#6b7280;font-size:13px}
  </style>
</head>
<body>
  <div class="container" role="main">
    <!-- SIDEBAR -->
    <aside class="sidebar" aria-label="Menu">
      <div class="brand" aria-hidden="true">
        <div class="logo">ASET</div>
        <div>
          <h1>ASET</h1>
          <p>Association des Étudiants et Stagiaires de Tétouan</p>
        </div>
      </div>

      <nav class="nav" aria-label="Navigation principale">
        <a href="#" aria-current="page">Accueil</a>
        <a href="#">Candidats</a>
        <a href="#">Voter</a>
        <a href="#">Résultats</a>
      </nav>

      <div class="meta" style="margin-top:8px">
        <div class="k">Date du scrutin</div>
        <div class="v">15 Novembre 2025</div>
      </div>

      <div class="meta" style="display:flex;gap:8px;flex-direction:column">
        <div style="display:flex;gap:8px">
          <div style="flex:1">
            <div class="k">Candidats</div>
            <div class="v">3 Candidats</div>
          </div>
          <div style="flex:1">
            <div class="k">Inscrits</div>
            <div class="v">1,250 Étudiants</div>
          </div>
        </div>

        <div style="margin-top:8px">
          <div class="k">Statut</div>
          <div class="v" style="color:#0ea5a4">Vote ouvert</div>
        </div>
      </div>

      <div style="margin-top:auto">
        <small class="muted">© 2025 ASET - Association des Étudiants et Stagiaires de Tétouan</small>
      </div>
    </aside>

    <!-- MAIN -->
    <section class="main">
      <!-- HERO -->
      <header class="hero" role="banner" aria-label="Bannière principale">
        <div class="hero-left">
          <span class="eyebrow">Plateforme de vote sécurisée</span>
          <h1 class="title">Élections du Président ASET 2025</h1>
          <p class="subtitle">Participez à l'élection du nouveau président de l'Association des Étudiants et Stagiaires de Tétouan</p>

          <div class="cta">
            <button class="btn-primary" onclick="location.href='#voter'">Voter maintenant</button>
          </div>

          <div class="info-block" role="group" aria-label="Slogan">
            <div class="stat" aria-hidden="true">
              <div class="label">Fraternité</div>
            </div>
            <div class="stat" aria-hidden="true">
              <div class="label">Discipline</div>
            </div>
            <div class="stat" aria-hidden="true">
              <div class="label">Travail</div>
            </div>
          </div>
        </div>

        <div class="hero-right" aria-hidden="true">
          <!-- Card résumé -->
          <div style="width:100%" class="card">
            <div style="display:flex;justify-content:space-between;align-items:center">
              <div>
                <small class="muted">Date du scrutin</small>
                <div style="font-weight:800;font-size:16px;margin-top:6px">15 Novembre 2025</div>
              </div>
              <div style="text-align:right">
                <small class="muted">Statut</small>
                <div style="font-weight:800;color:#0ea5a4;margin-top:6px">Vote ouvert</div>
              </div>
            </div>
            <hr style="border:0;border-top:1px solid #f1f5f9;margin:12px 0">
            <div style="font-size:14px;color:#374151"><strong>Candidats :</strong> 3 Candidats</div>
            <div style="font-size:14px;color:#374151;margin-top:6px"><strong>Inscrits :</strong> 1,250 Étudiants</div>
          </div>

          <!-- Short about -->
          <div style="width:100%" class="card about" aria-label="À propos">
            <h3>À propos de l'ASET</h3>
            <p>L'Association des Étudiants et Stagiaires de Tétouan (ASET) est une organisation estudiantine qui représente et défend les intérêts des étudiants et stagiaires de la région de Tétouan. Notre mission est de créer un environnement académique et social propice à l'épanouissement de tous les membres, en organisant des activités culturelles, sportives et éducatives.</p>
          </div>
        </div>
      </header>

      <!-- HOW TO VOTE -->
      <article class="card" aria-labelledby="howto">
        <h3 id="howto">Comment voter ?</h3>
        <div class="steps" role="list">
          <div class="step" role="listitem">
            <div class="num">1</div>
            <div class="text">Consultez les profils des candidats dans la section "Candidats"</div>
          </div>
          <div class="step" role="listitem">
            <div class="num">2</div>
            <div class="text">Rendez-vous dans la section "Voter" et sélectionnez votre candidat</div>
          </div>
          <div class="step" role="listitem">
            <div class="num">3</div>
            <div class="text">Confirmez votre choix pour valider votre vote</div>
          </div>
        </div>
      </article>

      <!-- FOOTER -->
      <footer>
        <p style="font-weight:800;margin-bottom:6px">ASET</p>
        <p class="muted">Plateforme de vote sécurisée pour les élections présidentielles</p>
        <small class="muted">Fraternité • Discipline • Travail</small>
      </footer>
    </section>
  </div>
</body>
</html>

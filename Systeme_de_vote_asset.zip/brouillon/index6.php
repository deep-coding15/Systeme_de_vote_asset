<?php
// index.php - Dashboard approximatif "Site de gestion de vote"
// Save and run: php -S localhost:8000
?>
<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Dashboard - Gestion de vote</title>
  <style>
    /* Variables & reset */
    :root{
      --bg:#f6f7fb;
      --card:#ffffff;
      --muted:#7b88a6;
      --primary:#3b82f6;
      --accent:#06b6d4;
      --glass: rgba(255,255,255,0.7);
      --radius:14px;
      --shadow: 0 6px 18px rgba(37,50,80,0.08);
      font-family: Inter, ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;
    }
    *{box-sizing:border-box; margin:0; padding:0}
    html,body{height:100%}
    body{
      background: linear-gradient(180deg, #eef2ff 0%, var(--bg) 100%);
      color:#172031;
      font-size:15px;
      line-height:1.4;
    }

    /* Layout */
    .app{
      display:flex;
      min-height:100vh;
      gap:24px;
      padding:28px;
    }
    .sidebar{
      width:260px;
      background: linear-gradient(180deg, rgba(59,130,246,0.06), rgba(6,182,212,0.03));
      border-radius:18px;
      padding:20px;
      box-shadow:var(--shadow);
      flex-shrink:0;
      display:flex;
      flex-direction:column;
      gap:18px;
    }
    .brand{
      display:flex; align-items:center; gap:12px;
    }
    .logo{
      width:48px; height:48px;
      border-radius:10px;
      background:linear-gradient(135deg,var(--primary),var(--accent));
      display:flex; align-items:center; justify-content:center;
      color:white; font-weight:700;
      box-shadow:0 6px 14px rgba(59,130,246,0.18);
    }
    .brand h1{font-size:16px}
    .nav{margin-top:4px; display:flex; flex-direction:column; gap:6px;}
    .nav a{
      display:flex; gap:12px; align-items:center;
      padding:10px; border-radius:10px;
      color:var(--muted); text-decoration:none; font-weight:600;
    }
    .nav a.active{background:var(--card); color:var(--primary); box-shadow:var(--shadow)}
    .nav a svg{opacity:0.9}

    .main{
      flex:1;
      display:flex;
      flex-direction:column;
      gap:20px;
    }

    .topbar{
      display:flex; justify-content:space-between; align-items:center;
      gap:12px;
    }
    .search{
      flex:1; max-width:520px;
      background:var(--card); border-radius:12px; padding:10px 14px;
      display:flex; gap:10px; align-items:center; box-shadow:var(--shadow);
    }
    .search input{border:0; outline:none; flex:1; font-size:14px; background:transparent}
    .user{
      display:flex; align-items:center; gap:12px;
    }
    .avatar{width:40px; height:40px; border-radius:50%; background:linear-gradient(135deg,#f59e0b,#f97316); display:inline-flex; align-items:center; justify-content:center; color:#fff; font-weight:700}

    /* Content area */
    .grid{
      display:grid;
      grid-template-columns: repeat(3,1fr);
      gap:20px;
    }
    .card{
      background:var(--card); border-radius:var(--radius);
      padding:18px; box-shadow:var(--shadow);
    }
    .stat{
      display:flex; justify-content:space-between; align-items:center; gap:12px;
    }
    .stat .info{display:flex; flex-direction:column;}
    .stat .info .label{color:var(--muted); font-size:13px}
    .stat .info .value{font-size:20px; font-weight:700; margin-top:6px}

    .big{
      grid-column: span 2;
    }

    /* Table */
    table{width:100%; border-collapse:collapse}
    thead th{ text-align:left; padding:12px 14px; color:var(--muted); font-weight:700; font-size:13px}
    tbody td{padding:12px 14px; border-top:1px solid #eef1f6}
    .badge{padding:6px 10px; border-radius:999px; font-weight:700; font-size:13px}
    .badge.success{background:rgba(34,197,94,0.12); color:#16a34a}
    .badge.warn{background:rgba(250,204,21,0.12); color:#b45309}
    .actions button{border:0; background:transparent; cursor:pointer; margin-right:8px}

    /* Form */
    .form-row{display:flex; gap:12px}
    .input{flex:1; padding:10px 12px; border-radius:10px; border:1px solid #e6e9f2; background:#fff; outline:none}
    .btn{padding:10px 14px; border-radius:10px; border:0; background:var(--primary); color:white; font-weight:700; cursor:pointer}

    /* Responsive */
    @media (max-width:1000px){
      .grid{grid-template-columns: repeat(2,1fr)}
      .sidebar{display:none}
    }
    @media (max-width:640px){
      .grid{grid-template-columns: 1fr}
      .topbar{flex-direction:column; align-items:stretch}
      .search{max-width:none}
    }
  </style>
</head>
<body>
  <div class="app">
    <aside class="sidebar" aria-label="Navigation">
      <div class="brand">
        <div class="logo">V</div>
        <div>
          <h1>VoteManager</h1>
          <div style="color:var(--muted);font-size:13px">Admin Panel</div>
        </div>
      </div>

      <nav class="nav" role="navigation">
        <a href="#" class="active">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M3 12h18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
          Tableau de bord
        </a>
        <a href="#">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 3v18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
          Élections
        </a>
        <a href="#">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M3 6h18M3 12h18M3 18h18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
          Candidats
        </a>
        <a href="#">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="3" stroke="currentColor" stroke-width="2"/><path d="M5.5 20a6.5 6.5 0 0113 0" stroke="currentColor" stroke-width="2"/></svg>
          Utilisateurs
        </a>
        <a href="#">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M3 6h18M7 6v12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
          Paramètres
        </a>
      </nav>

      <div style="margin-top:auto;color:var(--muted);font-size:13px">
        © <?=date('Y')?> VoteManager
      </div>
    </aside>

    <main class="main">
      <header class="topbar">
        <div style="display:flex;gap:12px;align-items:center;flex:1">
          <div class="search" role="search">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M21 21l-4.35-4.35" stroke="#9aa6bf" stroke-width="2" stroke-linecap="round"/></svg>
            <input placeholder="Rechercher un électeur, un candidat, une élection..." />
          </div>
          <div style="display:flex;gap:8px">
            <button class="btn" style="background:transparent;color:var(--primary);box-shadow:none;border:1px solid rgba(59,130,246,0.12)">Nouveau</button>
          </div>
        </div>

        <div class="user">
          <div style="text-align:right">
            <div style="font-weight:700">Admin</div>
            <div style="color:var(--muted);font-size:13px">Administrateur</div>
          </div>
          <div class="avatar">A</div>
        </div>
      </header>

      <!-- quick stats -->
      <section class="grid">
        <div class="card stat">
          <div class="info">
            <div class="label">Élections actives</div>
            <div class="value">4</div>
          </div>
          <div style="text-align:right">
            <div style="font-size:12px;color:var(--muted)">En cours</div>
            <div style="font-weight:700;margin-top:8px">2 aujourd'hui</div>
          </div>
        </div>

        <div class="card stat">
          <div class="info">
            <div class="label">Total des électeurs</div>
            <div class="value">12 540</div>
          </div>
          <div style="text-align:right">
            <div style="font-size:12px;color:var(--muted)">Vérifiés</div>
            <div style="font-weight:700;margin-top:8px">11 876</div>
          </div>
        </div>

        <div class="card stat">
          <div class="info">
            <div class="label">Votes exprimés</div>
            <div class="value">8 342</div>
          </div>
          <div style="text-align:right">
            <div style="font-size:12px;color:var(--muted)">Participation</div>
            <div style="font-weight:700;margin-top:8px">66.5%</div>
          </div>
        </div>

        <!-- big panel -->
        <div class="card big">
          <h3 style="margin-bottom:12px">Détail des dernières élections</h3>

          <div style="display:flex;gap:14px;margin-bottom:14px;flex-wrap:wrap">
            <div style="flex:1;min-width:200px">
              <label style="display:block;color:var(--muted);font-size:13px;margin-bottom:6px">Filtrer par</label>
              <div style="display:flex;gap:8px">
                <input class="input" placeholder="Nom de l'élection" />
                <select class="input" style="max-width:160px">
                  <option>Etat</option>
                  <option>Active</option>
                  <option>Terminée</option>
                </select>
              </div>
            </div>

            <div style="min-width:200px">
              <label style="display:block;color:var(--muted);font-size:13px;margin-bottom:6px">Actions</label>
              <div style="display:flex;gap:8px">
                <button class="btn">Exporter</button>
                <button class="btn" style="background:#10b981">Créer</button>
              </div>
            </div>
          </div>

          <div style="overflow:auto">
            <table>
              <thead>
                <tr>
                  <th>Élection</th>
                  <th>Date début</th>
                  <th>Statut</th>
                  <th>Participants</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Présidentielle 2025</td>
                  <td>10/05/2025</td>
                  <td><span class="badge success">Active</span></td>
                  <td>5 123</td>
                  <td class="actions">
                    <button title="Voir">🔍</button>
                    <button title="Éditer">✏️</button>
                    <button title="Supprimer">🗑️</button>
                  </td>
                </tr>
                <tr>
                  <td>Municipales - Rabat</td>
                  <td>02/03/2025</td>
                  <td><span class="badge warn">Terminée</span></td>
                  <td>2 240</td>
                  <td class="actions">
                    <button title="Voir">🔍</button>
                    <button title="Éditer">✏️</button>
                  </td>
                </tr>
                <tr>
                  <td>Référendum transport</td>
                  <td>15/01/2025</td>
                  <td><span class="badge">Brouillon</span></td>
                  <td>0</td>
                  <td class="actions">
                    <button title="Éditer">✏️</button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <!-- right column small cards -->
        <div class="card">
          <h4 style="margin-bottom:12px">Récents utilisateurs</h4>
          <div style="display:flex;flex-direction:column;gap:12px">
            <div style="display:flex;align-items:center;gap:12px">
              <div style="width:44px;height:44px;border-radius:8px;background:linear-gradient(135deg,#fb7185,#f97316);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700">MN</div>
              <div style="flex:1">
                <div style="font-weight:700">Mouna Najib</div>
                <div style="color:var(--muted);font-size:13px">Vérifié</div>
              </div>
              <div style="color:var(--muted);font-size:13px">2 jours</div>
            </div>
            <div style="display:flex;align-items:center;gap:12px">
              <div style="width:44px;height:44px;border-radius:8px;background:linear-gradient(135deg,#60a5fa,#06b6d4);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700">RB</div>
              <div style="flex:1">
                <div style="font-weight:700">Rachid Ben</div>
                <div style="color:var(--muted);font-size:13px">En attente</div>
              </div>
              <div style="color:var(--muted);font-size:13px">4 jours</div>
            </div>
          </div>
        </div>
      </section>

      <footer style="color:var(--muted);font-size:13px;margin-top:auto;padding-top:8px">
        Conçu pour la gestion sécurisée des élections — modèle d'interface.
      </footer>
    </main>
  </div>
</body>
</html>

<?php
// index.php - Reproduction soignée d'un dashboard "Site de gestion de vote"
// Run: php -S localhost:8000
?>
<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Vote Dashboard - Reproduction Figma (approx.)</title>

  <!-- fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800&display=swap" rel="stylesheet">

  <style>
    :root{
      --bg:#f4f6fb;
      --panel:#ffffff;
      --muted:#7b8394;
      --primary:#3751ff;
      --accent:#00c2b3;
      --danger:#ff6b6b;
      --radius:12px;
      --shadow: 0 8px 24px rgba(27,38,63,0.08);
      font-family: "Inter", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;
    }
    *{box-sizing:border-box}
    html,body{height:100%}
    body{
      margin:0; background:linear-gradient(180deg,#eef3ff 0%,var(--bg) 100%);
      color:#12202b; -webkit-font-smoothing:antialiased; -moz-osx-font-smoothing:grayscale;
      font-size:15px;
    }

    /* App layout */
    .app{display:flex; gap:24px; padding:28px; min-height:100vh}
    .sidebar{
      width:260px; background:linear-gradient(180deg,rgba(55,81,255,0.06),rgba(0,194,179,0.03));
      border-radius:16px; padding:20px; box-shadow:var(--shadow); flex-shrink:0;
      display:flex; flex-direction:column; gap:18px;
    }
    .brand{display:flex; gap:12px; align-items:center}
    .logo{
      width:52px; height:52px; border-radius:12px;
      background:linear-gradient(135deg,var(--primary),var(--accent));
      display:flex; align-items:center; justify-content:center; color:white; font-weight:800; font-size:20px;
      box-shadow:0 6px 18px rgba(55,81,255,0.18);
    }
    .brand .title{font-weight:700; font-size:16px}
    .brand .subtitle{font-size:13px; color:var(--muted)}

    nav.nav{display:flex; flex-direction:column; gap:8px; margin-top:6px}
    nav.nav a{
      display:flex; align-items:center; gap:12px; padding:10px; border-radius:10px;
      color:var(--muted); text-decoration:none; font-weight:600;
    }
    nav.nav a.active{background:var(--panel); color:var(--primary); box-shadow:var(--shadow)}
    nav.nav svg{opacity:0.85}

    .main{flex:1; display:flex; flex-direction:column; gap:18px}

    /* topbar */
    .topbar{display:flex; justify-content:space-between; align-items:center; gap:12px}
    .search{
      display:flex; align-items:center; gap:10px; padding:10px 14px; background:var(--panel);
      border-radius:12px; box-shadow:var(--shadow); min-width:240px; max-width:680px; width:60%;
    }
    .search input{border:0; outline:none; background:transparent; font-size:14px; width:100%}
    .actions{display:flex; gap:10px; align-items:center}
    .btn{padding:10px 14px; border-radius:10px; border:0; background:var(--primary); color:white; font-weight:700; cursor:pointer}
    .ghost{background:transparent;color:var(--primary);border:1px solid rgba(55,81,255,0.12)}

    .user{display:flex; gap:12px; align-items:center}
    .avatar{width:44px; height:44px; border-radius:10px; background:linear-gradient(135deg,#ffb86b,#ff6b6b);
           display:flex; align-items:center; justify-content:center; color:#fff; font-weight:800}

    /* grid */
    .grid{display:grid; grid-template-columns: repeat(12, 1fr); gap:18px}
    .card{background:var(--panel); border-radius:12px; padding:16px; box-shadow:var(--shadow)}
    .col-4{grid-column:span 4}
    .col-8{grid-column:span 8}
    .col-12{grid-column:span 12}

    .stat-row{display:flex; gap:12px}
    .stat{
      flex:1; padding:14px; border-radius:12px; display:flex; justify-content:space-between; align-items:center;
      background:linear-gradient(180deg, rgba(255,255,255,0.9), rgba(255,255,255,0.85));
      border:1px solid #f0f4ff;
    }
    .stat .meta{color:var(--muted); font-size:13px}
    .stat .num{font-weight:800; font-size:20px; margin-top:6px}

    /* table */
    .table-wrap{overflow:auto}
    table{width:100%; border-collapse:collapse; min-width:720px}
    thead th{font-size:13px; color:var(--muted); text-align:left; padding:12px 14px}
    tbody td{padding:12px 14px; border-top:1px solid #f1f4fb}
    .badge{display:inline-block;padding:6px 10px;border-radius:999px;font-weight:700;font-size:13px}
    .badge.active{background:rgba(56,161,105,0.12); color:#16a34a}
    .badge.draft{background:rgba(99,102,241,0.08); color:#4f46e5}
    .badge.closed{background:rgba(245,158,11,0.09); color:#b45309}

    /* form */
    .form-grid{display:grid; grid-template-columns: repeat(3,1fr); gap:12px}
    .field{padding:10px 12px; border-radius:10px; border:1px solid #eef2ff; background:white}

    /* small utilities */
    h2{margin:0 0 10px 0; font-size:18px}
    p.muted{color:var(--muted); font-size:13px; margin:0}

    /* responsive */
    @media (max-width:1100px){
      .grid{grid-template-columns: repeat(6,1fr)}
      .col-8{grid-column:span 6}
      .col-4{grid-column:span 6}
      .sidebar{display:none}
    }
    @media (max-width:640px){
      .topbar{flex-direction:column; align-items:stretch}
      .search{width:100%}
      .grid{grid-template-columns: repeat(1,1fr)}
      .col-4,.col-8,.col-12{grid-column:span 1}
    }
  </style>
</head>
<body>
  <div class="app">
    <aside class="sidebar" aria-label="Sidebar">
      <div class="brand">
        <div class="logo">V</div>
        <div>
          <div class="title">Site de vote</div>
          <div class="subtitle">Panneau d'administration</div>
        </div>
      </div>

      <nav class="nav" role="navigation" aria-label="Main">
        <a href="#" class="active">Tableau de bord</a>
        <a href="#">Élections</a>
        <a href="#">Candidats</a>
        <a href="#">Électeurs</a>
        <a href="#">Rapports</a>
        <a href="#">Paramètres</a>
      </nav>

      <div style="margin-top:auto;color:var(--muted);font-size:13px">© <?=date('Y')?> Vote</div>
    </aside>

    <main class="main">
      <header class="topbar">
        <div style="display:flex; align-items:center; gap:12px; flex:1">
          <div class="search" role="search">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M21 21l-5-5" stroke="#9aa6bf" stroke-width="2" stroke-linecap="round"/></svg>
            <input placeholder="Rechercher électeur, candidat, élection..." />
          </div>

          <div class="actions">
            <button class="btn ghost">Importer</button>
            <button class="btn">Nouveau</button>
          </div>
        </div>

        <div class="user">
          <div style="text-align:right">
            <div style="font-weight:800">Admin</div>
            <div class="muted">Administrateur</div>
          </div>
          <div class="avatar">AN</div>
        </div>
      </header>

      <section class="grid" style="align-items:start">
        <!-- stats -->
        <div class="card col-8">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
            <h2>Vue d'ensemble</h2>
            <p class="muted">Dernières 24h • Mise à jour automatique</p>
          </div>

          <div class="stat-row" style="margin-bottom:14px">
            <div class="stat">
              <div>
                <div class="meta">Élections actives</div>
                <div class="num">3</div>
              </div>
              <div style="text-align:right;color:var(--muted);font-weight:700">+1</div>
            </div>

            <div class="stat">
              <div>
                <div class="meta">Électeurs totaux</div>
                <div class="num">12 540</div>
              </div>
              <div style="text-align:right;color:var(--muted);font-weight:700">11 876 vérifiés</div>
            </div>

            <div class="stat">
              <div>
                <div class="meta">Participation</div>
                <div class="num">66.5%</div>
              </div>
              <div style="text-align:right;color:var(--muted);font-weight:700">8 342 votes</div>
            </div>
          </div>

          <!-- table -->
          <div class="table-wrap">
            <table aria-label="Tableau des élections">
              <thead>
                <tr>
                  <th>Élection</th>
                  <th>Début</th>
                  <th>Fin</th>
                  <th>Statut</th>
                  <th>Participants</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Présidentielle 2025</td>
                  <td>10/05/2025</td>
                  <td>10/06/2025</td>
                  <td><span class="badge active">Active</span></td>
                  <td>5 123</td>
                  <td>
                    <button title="Voir">🔍</button>
                    <button title="Modifier">✏️</button>
                    <button title="Exporter">⬇️</button>
                  </td>
                </tr>
                <tr>
                  <td>Municipales - Rabat</td>
                  <td>02/03/2025</td>
                  <td>10/03/2025</td>
                  <td><span class="badge closed">Terminée</span></td>
                  <td>2 240</td>
                  <td>
                    <button title="Voir">🔍</button>
                    <button title="Rapport">📄</button>
                  </td>
                </tr>
                <tr>
                  <td>Référendum - Transport</td>
                  <td>15/01/2025</td>
                  <td>20/01/2025</td>
                  <td><span class="badge draft">Brouillon</span></td>
                  <td>0</td>
                  <td>
                    <button title="Modifier">✏️</button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <!-- right column -->
        <div class="card col-4">
          <h2>Actions rapides</h2>
          <div style="display:flex;flex-direction:column; gap:10px; margin-top:10px">
            <button class="btn">Créer une élection</button>
            <button class="btn ghost">Importer électeurs</button>
            <button class="btn" style="background:#10b981">Générer rapport</button>
          </div>

          <hr style="margin:14px 0;border:0;border-top:1px solid #f1f4fb">

          <h3 style="margin:0 0 8px 0">Utilisateurs récents</h3>
          <div style="display:flex;flex-direction:column;gap:12px;margin-top:8px">
            <div style="display:flex;gap:10px;align-items:center">
              <div style="width:44px;height:44px;border-radius:8px;background:linear-gradient(135deg,#60a5fa,#06b6d4);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800">MN</div>
              <div style="flex:1">
                <div style="font-weight:700">Mouna Najib</div>
                <div style="color:var(--muted);font-size:13px">Vérifié • 2j</div>
              </div>
            </div>
            <div style="display:flex;gap:10px;align-items:center">
              <div style="width:44px;height:44px;border-radius:8px;background:linear-gradient(135deg,#f59e0b,#f97316);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800">RB</div>
              <div style="flex:1">
                <div style="font-weight:700">Rachid Ben</div>
                <div style="color:var(--muted);font-size:13px">En attente • 4j</div>
              </div>
            </div>
          </div>
        </div>

        <!-- full width form -->
        <div class="card col-12">
          <h2>Créer / éditer une élection</h2>
          <div style="margin-top:10px; display:flex; gap:12px; flex-direction:column">
            <div class="form-grid" style="grid-template-columns:repeat(3,1fr);">
              <input class="field" placeholder="Nom de l'élection" />
              <input class="field" type="date" />
              <input class="field" type="date" />
            </div>
            <div style="display:flex; gap:10px; margin-top:8px">
              <select class="field" style="max-width:220px">
                <option>Statut: Active</option>
                <option>Terminée</option>
                <option>Brouillon</option>
              </select>
              <input class="field" placeholder="Nombre de participants estimés" />
              <div style="flex:1"></div>
              <div style="display:flex; gap:8px;">
                <button class="btn">Sauvegarder</button>
                <button class="btn ghost">Annuler</button>
              </div>
            </div>
          </div>
        </div>

      </section>

      <footer style="color:var(--muted); font-size:13px; padding-top:8px">Reproduction approximative — pour copie exacte : fournis des exports PNG/SVG/PDF ou une capture.</footer>
    </main>
  </div>
</body>
</html>

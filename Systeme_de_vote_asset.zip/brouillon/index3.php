<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <header>
        <div>
            <img src="logo_asset.png" alt="logo asset">
            <div style="display: inline;">
                <p>ASSET</p>
                <p>Association des Etudiants et Stagiaires de Tétouan</p>f
            </div>
        </div>
        <div>
            <img src="photo_avatar.png" alt="photo avatar">
            <span style="display: block;">Profile</span>
        </div>
    </header>
    <nav style="display: flex; gap: 10px;">
        <a href="#">
            <svg>icone-accueil</svg>
            <span>Accueil</span>
        </a>
        <a href="#">
            <svg>icone-candidats</svg>
            <span>Candidats</span>
        </a>
        <a href="#">
            <svg>icone-check-valider-dans-ordinateur</svg>
            <span>Voter</span>
        </a>
        <a href="#">
            <svg>icone-graphique</svg>
            <span>Résulats</span>
        </a>
    </nav>

    <main>
        <section>
            <!-- image de vote en background a mettre -->
            <h2>Elections du président ASSET 2025</h2>
            <h3>Participez à l'élection du nouveau président de l'association des étudiants et stagiaires de Tétouan.</h3>
            <a href="lien-vers-la-page-vote">VOTER MAINTENANT</a>
        </section>
        <section>
            <div>
                <svg>calendrier</svg>
                <div style="display: inline-block;">
                    <p>Date du scrutin</p>
                    <p>15 Novembre 2025</p>
                </div>
            </div>
            <div>
                <svg>2-personnes</svg>
                <div style="display: inline-block;">
                    <p>Candidats</p>
                    <p>3 Candidats</p><!-- A remplacer ici avec AJAX -->
                </div>
            </div>
            <div>
                <svg>icone-check-valider-dans-ordinateur</svg>
                <div style="display: inline-block;">
                    <p>Inscrits</p>
                    <p>152 Inscrits</p>
                </div>
            </div>
            <div>
                <svg>icone-check-valider</svg>
                <div style="display: inline-block;">
                    <p>Statut</p>
                    <p>Vote Ouvert</p>
                </div>
            </div>
        </section>
        <section>
            <h2>A propos de l'ASSET</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugit debitis ea nesciunt reiciendis repellendus delectus soluta vero nihil incidunt natus. Vel eveniet iusto sint magni deleniti. Ex illum similique quia necessitatibus assumenda modi nobis quam eligendi, adipisci sequi quaerat quidem possimus minus veritatis, voluptatum nemo eius cum quod deserunt porro?</p>
        </section>
        <section>
            <h2>Comment voter ?</h2>
            <a href="#">
                <svg>icone-1-dans-cercle</svg>
                <p>Consultez les profils des candidats dans la section "Candidats"</p>
            </a>
            <a href="#">
                <svg>icone-2-dans-cercle</svg>
                <p>Rendez-vous dans la section "Voter" et sélectionnez votre candidat</p>
            </a>
            <a href="#">
                <svg>icone-3-dans-cercle</svg>
                <p>Confirmez votre choix pour valider votre vote</p>
            </a>
        </section>
    </main>
    <footer>
        <p>© 2025 ASET - Association des Étudiants et Stagiaires de Tétouan</p>
        <p>Plateforme de vote sécurisée pour les élections présidentielles</p>
        <p>Fraternité • Discipline • Travail</p>
    </footer>
</body>

</html>
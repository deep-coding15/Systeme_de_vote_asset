<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Élections ASSET 2025</title>
    <style>
        :root {
            --primary-color: #ff6b6b;
            --primary-light: #ff9e9e;
            --white: #ffffff;
            --light-gray: #f5f5f5;
            --dark-gray: #333333;
            --medium-gray: #666666;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --border-radius: 8px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--white);
            color: var(--dark-gray);
            line-height: 1.6;
        }

        header {
            background-color: var(--white);
            padding: 15px 5%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: var(--shadow);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .logo-container {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo-container img {
            height: 50px;
            width: auto;
        }

        .logo-text p:first-child {
            font-size: 1.5rem;
            font-weight: bold;
            color: var(--primary-color);
        }

        .logo-text p:last-child {
            font-size: 0.8rem;
            color: var(--medium-gray);
        }

        .profile-container {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .profile-container:hover {
            transform: translateY(-2px);
        }

        .profile-container img {
            height: 40px;
            width: 40px;
            border-radius: 50%;
            border: 2px solid var(--primary-light);
        }

        .profile-container span {
            font-weight: 500;
            color: var(--primary-color);
        }

        nav {
            background-color: var(--primary-color);
            padding: 15px 5%;
            display: flex;
            justify-content: center;
            gap: 30px;
            box-shadow: var(--shadow);
        }

        nav a {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: var(--white);
            font-weight: 500;
            transition: all 0.3s ease;
            padding: 5px 10px;
            border-radius: var(--border-radius);
        }

        nav a:hover {
            background-color: var(--primary-light);
            transform: translateY(-3px);
        }

        .icon-placeholder {
            width: 24px;
            height: 24px;
            background-color: var(--white);
            border-radius: 50%;
            margin-bottom: 5px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            color: var(--primary-color);
        }

        main {
            padding: 40px 5%;
        }

        .hero {
            background: linear-gradient(rgba(255, 107, 107, 0.8), rgba(255, 107, 107, 0.9)), url('vote-background.jpg');
            background-size: cover;
            background-position: center;
            padding: 80px 20px;
            text-align: center;
            border-radius: var(--border-radius);
            margin-bottom: 40px;
            color: var(--white);
            box-shadow: var(--shadow);
        }

        .hero h2 {
            font-size: 2.5rem;
            margin-bottom: 20px;
        }

        .hero h3 {
            font-size: 1.2rem;
            margin-bottom: 30px;
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
        }

        .cta-button {
            display: inline-block;
            background-color: var(--white);
            color: var(--primary-color);
            padding: 12px 30px;
            border-radius: 30px;
            text-decoration: none;
            font-weight: bold;
            font-size: 1.1rem;
            transition: all 0.3s ease;
            box-shadow: var(--shadow);
        }

        .cta-button:hover {
            background-color: var(--light-gray);
            transform: translateY(-3px);
            box-shadow: 0 6px 10px rgba(0, 0, 0, 0.15);
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }

        .stat-card {
            background-color: var(--white);
            padding: 25px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            display: flex;
            align-items: center;
            gap: 15px;
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            background-color: var(--primary-light);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--white);
            font-weight: bold;
        }

        .stat-text p:first-child {
            font-size: 0.9rem;
            color: var(--medium-gray);
        }

        .stat-text p:last-child {
            font-size: 1.3rem;
            font-weight: bold;
            color: var(--primary-color);
        }

        .about, .how-to-vote {
            background-color: var(--light-gray);
            padding: 40px;
            border-radius: var(--border-radius);
            margin-bottom: 40px;
            box-shadow: var(--shadow);
        }

        .about h2, .how-to-vote h2 {
            color: var(--primary-color);
            margin-bottom: 20px;
            text-align: center;
        }

        .about p {
            text-align: justify;
            max-width: 800px;
            margin: 0 auto;
        }

        .steps {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }

        .step {
            background-color: var(--white);
            padding: 25px;
            border-radius: var(--border-radius);
            display: flex;
            align-items: center;
            gap: 15px;
            transition: all 0.3s ease;
            text-decoration: none;
            color: inherit;
        }

        .step:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);
        }

        .step-icon {
            width: 40px;
            height: 40px;
            background-color: var(--primary-color);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--white);
            font-weight: bold;
            flex-shrink: 0;
        }

        footer {
            background-color: var(--dark-gray);
            color: var(--white);
            padding: 30px 5%;
            text-align: center;
        }

        footer p {
            margin-bottom: 10px;
        }

        footer p:last-child {
            margin-top: 15px;
            font-weight: bold;
            color: var(--primary-light);
        }

        @media (max-width: 768px) {
            header {
                flex-direction: column;
                gap: 15px;
            }

            nav {
                flex-wrap: wrap;
                gap: 15px;
            }

            .hero h2 {
                font-size: 2rem;
            }

            .hero h3 {
                font-size: 1rem;
            }

            .stats {
                grid-template-columns: 1fr;
            }

            .steps {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>
    <header>
        <div class="logo-container">
            <img src="logo_asset.png" alt="logo asset">
            <div class="logo-text">
                <p>ASSET</p>
                <p>Association des Etudiants et Stagiaires de Tétouan</p>
            </div>
        </div>
        <div class="profile-container">
            <img src="photo_avatar.png" alt="photo avatar">
            <span>Profile</span>
        </div>
    </header>
    
    <nav>
        <a href="#">
            <div class="icon-placeholder">H</div>
            <span>Accueil</span>
        </a>
        <a href="#">
            <div class="icon-placeholder">C</div>
            <span>Candidats</span>
        </a>
        <a href="#">
            <div class="icon-placeholder">V</div>
            <span>Voter</span>
        </a>
        <a href="#">
            <div class="icon-placeholder">R</div>
            <span>Résultats</span>
        </a>
    </nav>

    <main>
        <section class="hero">
            <h2>Élections du président ASSET 2025</h2>
            <h3>Participez à l'élection du nouveau président de l'association des étudiants et stagiaires de Tétouan.</h3>
            <a href="lien-vers-la-page-vote" class="cta-button">VOTER MAINTENANT</a>
        </section>
        
        <section class="stats">
            <div class="stat-card">
                <div class="stat-icon">C</div>
                <div class="stat-text">
                    <p>Date du scrutin</p>
                    <p>15 Novembre 2025</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">P</div>
                <div class="stat-text">
                    <p>Candidats</p>
                    <p>3 Candidats</p><!-- A remplacer ici avec AJAX -->
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">I</div>
                <div class="stat-text">
                    <p>Inscrits</p>
                    <p>152 Inscrits</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">S</div>
                <div class="stat-text">
                    <p>Statut</p>
                    <p>Vote Ouvert</p>
                </div>
            </div>
        </section>
        
        <section class="about">
            <h2>À propos de l'ASSET</h2>
            <p>L'Association des Étudiants et Stagiaires de Tétouan (ASSET) est une organisation à but non lucratif qui œuvre pour le bien-être et la représentation des étudiants et stagiaires de la région. Fondée sur les principes de fraternité, de discipline et de travail, l'ASSET organise des événements culturels, des activités sociales et des programmes éducatifs pour ses membres. Notre mission est de créer un environnement favorable à l'épanouissement académique et personnel de tous les étudiants et stagiaires de Tétouan.</p>
        </section>
        
        <section class="how-to-vote">
            <h2>Comment voter ?</h2>
            <div class="steps">
                <a href="#" class="step">
                    <div class="step-icon">1</div>
                    <p>Consultez les profils des candidats dans la section "Candidats"</p>
                </a>
                <a href="#" class="step">
                    <div class="step-icon">2</div>
                    <p>Rendez-vous dans la section "Voter" et sélectionnez votre candidat</p>
                </a>
                <a href="#" class="step">
                    <div class="step-icon">3</div>
                    <p>Confirmez votre choix pour valider votre vote</p>
                </a>
            </div>
        </section>
    </main>
    
    <footer>
        <p>© 2025 ASSET - Association des Étudiants et Stagiaires de Tétouan</p>
        <p>Plateforme de vote sécurisée pour les élections présidentielles</p>
        <p>Fraternité • Discipline • Travail</p>
    </footer>
</body>

</html>